import fetch from "../include/fetch.js";
export function fetchCurrentTemperature(coords) {
    //Url containing the desire coordinates
    const link = `https://220.maxkuechen.com/currentTemperature/forecast?latitude=${coords.lat}&longitude=${coords.lon}&hourly=temperature_2m&temperature_unit=fahrenheit`;
    // Perform the fetch request
    return fetch(link)
        .then(data => {
        //Check if the data extracted from the api exists
        if (!data.ok) {
            throw new Error(`Error getting Temperature: ${data.statusText}`);
        }
        return data.json();
    })
        .then((data) => {
        // Extract the data
        const temperatureReading = {
            time: data.hourly.time,
            temperature_2m: data.hourly.temperature_2m,
        };
        return temperatureReading;
    })
        .catch(error => {
        //catching errors
        const errorMessage = error instanceof Error ? error.message : String(error);
        throw new Error(errorMessage);
    });
}
//# sourceMappingURL=fetchCurrentTemperature.js.map